/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import javax.swing.JFrame;
public class List {
    


    public static void main(String[] args) {
        Table fenetre = new Table();
        fenetre.setSize(490, 300);
        fenetre.setTitle("Liste des dépenses");
        fenetre.setResizable(false);
        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenetre.setLocationRelativeTo(null);
        
        fenetre.setVisible(true);
    }
    
}


